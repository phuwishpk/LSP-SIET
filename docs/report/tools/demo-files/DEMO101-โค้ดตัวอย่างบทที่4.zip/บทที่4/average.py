def average(numbers):
    return sum(numbers) / len(numbers) if numbers else 0


print(average([3, 4, 5]))
