def grade(score):
    """คืนเกรด A-F ตามช่วงคะแนน"""
    if score >= 80:
        return "A"
    if score >= 70:
        return "B"
    if score >= 60:
        return "C"
    if score >= 50:
        return "D"
    return "F"


print(grade(75))
